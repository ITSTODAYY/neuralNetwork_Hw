## How To Run 
Copy the datas into path /codes. Open the terminal under this index and type python run_mlp.py. 
## The Performance Of The Model
This is the best performance model and the accuracy can reach 0.99.
